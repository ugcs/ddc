#!/bin/bash
#
# swarm.bash locations_file [swarm_id [default_params_file]]
#
# Launches multiple SITL instances uisng only arducopter binary.
# - No cloning of repository/building/any other files are neccessary.
# - Script creates a directory ddc_cache under this script directory for each vehicle to keep eeprom separate.
# - Waits for keypress to terminate all instances automatically.
# - To run multiple instances of the script each instance must specify swarm_id (1-6), default = 1
# - Each SITL will listen on its own tcp port in form <swarm_id><MAVID>0.
#   I.e. vehicle with mav id 13 on swarm 3 will be avialable on port 30130.
# - All sitl console output is being logged to file console.log in its cache directory
# - default_params_file is used as parameter file for all copters. Default: defaults.parm
# - To reset the setup and start from scratch, delete all swarm directories swarm1..swarm6
#
# Locations file must be in format "[MAV_ID]=lat,lon,alt,hdg", no spaces.
# lat, lon and hdg are in decimal degrees.
# altitude is in meters AMSL
# The script will read and launch as many instances as specified in locations file.
# Example:
# [104]=33.8096463,-84.1441550,279,0
# [119]=33.809659,-84.143735,279,0
#
# If location file is invalid or does not contain any valid lcoation then the default (Spilve) is used.
#

# This scripts directory.
MY_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
# script launched from this directory
RUN_DIR=$(pwd)

# file containing default parameters for copter.
if [ -n "$3" ]
then
    DEFAULTS=$3
else
    DEFAULTS=$MY_DIR/Tools/autotest/default_params/copter.parm
fi

if [ -f $DEFAULTS ]
then
    echo "Using $DEFAULTS as default parameters"
else
    echo "$DEFAULTS file not found! Please provide parameter file"
    exit
fi

# assume arducopter binary is located in the same directory as this script.
SIM_COMMAND="$MY_DIR/build/sitl/bin/arducopter"

chmod +x $MY_DIR/build/sitl/bin/arducopter


# Get the swarm ID
if [ -z "$2" ]
then
    SWARM_ID="1"
else
    if [ "$2" == "1" ] || [ "$2" == "2" ] || [ "$2" == "3" ] || [ "$2" == "4" ] || [ "$2" == "5" ] || [ "$2" == "6" ]
    then
        SWARM_ID=$2
    else
        echo "Invalid swarm id. Must be number from 1 to 6"
        exit
    fi
fi

# Check for already running swarm...
if [ -n "$(pgrep -f "base-port $SWARM_ID")" ]
then
    echo "Someone is already running swarm $SWARM_ID on this host. Choose another number from 1 to 6."
    exit
fi
echo "SWARM_ID = $SWARM_ID"

# parse the locations file
let LOC_COUNT=0
if [ -n "$1" ]; then
    if [ -f "$1" ]; then
        echo "Reading locations from $1"
        # location file line matcher.
        REGE="^[[:alpha:]]*S([0-9]+)=([-+]?[0-9]*\.?[0-9]+),([-+]?[0-9]*\.?[0-9]+),([-+]?[0-9]*\.?[0-9]+),([-+]?[0-9]*\.?[0-9]+)"
        echo "ID = lat lon alt hdg"
        while IFS='' read -r line || [[ -n "$line" ]]; do
            if [[ $line =~ $REGE ]]
            then
                L[${BASH_REMATCH[1]}]=${BASH_REMATCH[2]},${BASH_REMATCH[3]},${BASH_REMATCH[4]},${BASH_REMATCH[5]}
                echo ${BASH_REMATCH[1]} = ${BASH_REMATCH[2]} ${BASH_REMATCH[3]} ${BASH_REMATCH[4]} ${BASH_REMATCH[5]}
                let LOC_COUNT=LOC_COUNT+1
            fi
        done < "$1"
        if (( LOC_COUNT==0 )); then
            echo "File $1 did not contain valid locations."
        else
            echo "$LOC_COUNT locations read."
        fi
    else
        echo "Locations file $1 not found."
    fi
else
    echo "Locations file not specified."
fi

# detault to one vehicle if locations parsing failed.
if (( $LOC_COUNT == 0 )); then
    echo "Using one vehicle [101] at default location."
    for id in $(seq 101 101); do
       L[$id]=56.98,24.07,1,13
    done
fi

# Terminate all launched processes on script exit
function clean_up {
    # kill all SITLs belonging to this swarm only.
    kill $(pgrep -f "base-port $SWARM_ID")
}
trap clean_up EXIT

# Create a directory for each instance local data.
TMP_DIR=$MY_DIR/swarm$SWARM_ID
echo "Using temp directory $TMP_DIR for copter local data"

# Take a best guess on local ip address.
# Take first ip from all local ips. If the second is required in your setup then change -f1 to -f2.
LOCAL_IP=$(hostname -I |cut -f1 -d' ')

#remove SYSID_THISMAV from deafult.parm if it is there.
sed -i '/SYSID_THISMAV/d' $DEFAULTS

# Create SITL instances
echo ""
echo ""
echo "VSM configuration:"
echo ""
for id in $(seq 1 254); do
    if [ -n "${L[$id]}" ]; then

        # cd to initial dir to handle eventual relative path to defaults.
        cd $RUN_DIR

        # Create the cache dir
        mkdir -p $TMP_DIR/$id
        cp $DEFAULTS $TMP_DIR/$id/defaults.parm
        cd $TMP_DIR/$id

        # TCP port sitl will listen on.
        PORT=$(printf "$SWARM_ID%03d0" $id)

        # UDP port sitl will listen for RC. Not used in our setup but must make sure it does not conflict with others.
        RCINPORT=$(printf "$SWARM_ID%03d9" $id)

        # Create deafult config for each vehicle and set sysid.
        echo "SYSID_THISMAV $id" >> defaults.parm
        
        # Show corresponding VSM config
        echo "connection.tcp_out.$id.port = $PORT"
        echo "connection.tcp_out.$id.address = $LOCAL_IP"
        
        # Run detached from cache directory and save all output to console.log
        $SIM_COMMAND -I$id --home ${L[$id]} --model + --defaults defaults.parm --rc-in-port $RCINPORT --base-port $PORT > console.log 2>&1 &
    fi
done
echo ""

# Wait for keypress. clean_up will clean up.
read -rsp $'Press any key to terminate...\n' -n1 key

