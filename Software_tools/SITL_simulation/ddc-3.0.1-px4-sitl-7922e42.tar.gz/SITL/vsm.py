import argparse

parser = argparse.ArgumentParser(description='Generates vsm config part')
parser.add_argument('--host', help='Sitls host to connect',  required=True)
parser.add_argument('--num', help='Number of sitl instances', type=int,  required=True)

args = parser.parse_args()

for i in range(1, args.num + 1):
    print "# N %d"  %(i)
    print "connection.tcp_out.%d.port = %d" %(i, 5760 + i*10 + 2)
    print "connection.tcp_out.%d.address = %s" %(i,args.host)

