Run:

swarm_fast.bash Tools/autotest/locations.txt