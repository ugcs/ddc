Run:

swarm.bash 

ot

swarm_fast.bash Tools/autotest/locations.txt