import math
from random import randint

Y_count = 7  
X_count = 5
Distance_between_drones = 3  # meters

# first ID in generated list. CHange it to whatever
# ID you want but please note that ID of any drone
# cannot be larger that 255 and must be larger than zero. 
First_drone_ID = 101

CNT_LAT = 56.973501
CNT_LON = 24.071459
Heading = 0
Altitude = 1

Pi = 3.141592654

R=6378137

S = First_drone_ID

for x in range(0, X_count):
    for y in range(0, Y_count):
        heading_rad = Heading * Pi / 180.0
        offset_x = (x - (X_count - 1) / 2) * Distance_between_drones
        offset_y = (y - (Y_count - 1) / 2) * Distance_between_drones

        #rotate
        new_offset_x = offset_x * math.cos(heading_rad) - offset_y * math.sin(heading_rad)
        new_offset_y = offset_x * math.sin(heading_rad) + offset_y * math.cos(heading_rad)

        dLat = new_offset_x / R
        dLon = new_offset_y / (R * math.cos(Pi * CNT_LAT / 180))

        lat = CNT_LAT + dLat * 180 / Pi
        lon = CNT_LON + dLon * 180 / Pi 
        
        print("S" + str(S) + "=" + str(lat) + "," + str(lon) + "," + str(Altitude) + "," + str(randint(0, 359))) 
        S = S + 1


