#!/bin/bash

# swarm.bash sysid_first sysid_last

# Launches multiple SITL instances from single ardupilot repository copy.
# - You need to set up 4 parameters below:
#   1) AP_DIR Your ardupilot source repository with precompiled SITL build.
#   2) SYSID_FIRST
#   3) SYSID_LAST
#   4) VSM_PORT
# - Script creates a directory ddc_cache under this script directory for each vehicle to keep eeprom separate.
# - Waits for keypress to terminate all instances automatically.
# - First launch will initalize the the SYSID_THISMAV for all instances. 
#   It is required to stop/restart the script to force SITL to use the new SYSID_THISMAV.
#   After that it is saved into eeprom and will work on next launch.


# This scripts directory.
MY_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Range of system ids to use.
SYSID_FIRST=101
SYSID_LAST=120

chmod +x $MY_DIR/build/sitl/bin/arducopter
chmod +x $MY_DIR/Tools/autotest/sim_vehicle.py
chmod +x $MY_DIR/Tools/autotest/run_in_terminal_window.sh

# sysids can be overriden from cmdline
#[ -z "$2" ] || let SYSID_FIRST=$1 && let SYSID_LAST=$2

# IP:port of Ardupilot VSM
VSM_IP=192.168.1.33
VSM_PORT=14600

# Terminate all launched processes
function clean_up {
    # kill all SITLs
    kill $(pgrep -f "$SIM_COMMAND")
    # Kill all xterms assumming all of them are launched by SITLs.
    killall xterm
}

trap clean_up EXIT

# Simulation launcher command
# 3.4+ verson
SIM_COMMAND="$MY_DIR/Tools/autotest/sim_vehicle.py"

# Create a directory for each instance local data.
TMP_DIR=$MY_DIR/ddc-cache
echo "Using temp directory $TMP_DIR for copter local data"

# Create SITL instances
for id in $(seq $SYSID_FIRST $SYSID_LAST); do
  mkdir -p $TMP_DIR/$id
  rm $TMP_DIR/$id/mav.tlog*
  # 3.4+ python version
  #gnome-terminal -e "$SIM_COMMAND -I$id -L S$id -A \"-P SYSID_THISMAV=$id\" -N -v ArduCopter --out $VSM_PORT" --working-directory="$TMP_DIR/$id"
  
  #tcp
 echo "$SIM_COMMAND -I$id -L S$id -A \"-P SYSID_THISMAV=$id\" -N -v ArduCopter " --working-directory="$TMP_DIR/$id"
  gnome-terminal -e "$SIM_COMMAND -I$id -L S$id -A \"-P SYSID_THISMAV=$id\" -N -v ArduCopter " --working-directory="$TMP_DIR/$id"
  
  #udp different
  #PRT=$(($VSM_PORT+$id))
  #echo "Open UDP port " $PRT
  #gnome-terminal -e "$SIM_COMMAND -I$id -L S$id -A \"-P SYSID_THISMAV=$id\" -N -v ArduCopter --out $VSM_IP:$PRT" --working-directory="$TMP_DIR/$id"
  
  #udp single
  #gnome-terminal -e "$SIM_COMMAND -I$id -L S$id -A \"-P SYSID_THISMAV=$id\" -N -v ArduCopter --out $VSM_IP:14600" --working-directory="$TMP_DIR/$id"

  # <3.4 bash version.
  #gnome-terminal -e "$SIM_COMMAND -I$id --cmd \"param set SYSID_THISMAV $id\" -N -v ArduCopter --out $VSM_PORT" --working-directory="$TMP_DIR/$id"
done

# Wait for keypress. clean_up will clean up.
read -rsp $'Press any key to terminate...\n' -n1 key


